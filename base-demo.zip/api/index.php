<?php
include 'litephp/boot.inc.php';
use Lite\Core\Application;

$d = dirname(__DIR__).DIRECTORY_SEPARATOR.'protected'.DIRECTORY_SEPARATOR;
Application::init('www', $d, Application::MODE_API);