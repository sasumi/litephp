<?php
namespace www;
use Lite\Core\Application;

date_default_timezone_set('Asia/Shanghai');
include '../litephp/bootstrap.php';

//debug mode
set_error_handler('Lite\func\print_sys_error', ini_get('error_reporting'));

Application::init(__NAMESPACE__);