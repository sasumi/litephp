<?php
use function Lite\func\dump;

dump('app config required', 1);
return array(
	'site_name' => '管理后台',
	'url' => 'http://localhost/monitor/',
	'auto_statistics' => true,  //是否开启性能统计
	'auto_process_logic_error' => false,     //自动显示逻辑错误
	'debug' => true,
	'login_captcha' => true,
	'render' => '\www\ViewBase',
	'static' => 'http://localhost/monitor/static/',
	'cdn_url' => 'http://localhost/frontend/',
	'richeditor_home' => 'http://localhost/frontend/ueditor/',

	'default_image' => 'default_image.png',

	//登录控制
	'login' => array(
		'expired' => 3600,
		'use_captcha' => false,
		'allow_remember_in_frontend' => false,
		'captcha' => array(
			'width' => 100,
			'height' => 45,
			'words' => 4,
			'font_size' => 25
		)
	)
);