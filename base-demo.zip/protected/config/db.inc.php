<?php
use function Lite\func\dump;
dump('db config required', 1);
return array(
	'host' => 'localhost',
	'user' => 'root',
	'password' => '123456',
	'database' => '',
	'prefix' => ''
);