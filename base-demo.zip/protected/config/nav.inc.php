<?php
return array(
	array('首页', 'index'),
	array('流水日志', 'rpc', array(
		'流水日志' => array(
			array('RPC调用日志', 'rpc'),
			array('消息流水', 'bill'),
		),
	)),
//	array('系统设置', 'user', array(
//		'其他设置' => array(
//			array('用户', 'user'),
//			array('用户组', 'UserGroup'),
//			array('权限设置', 'access'),
//		),
//	)),
);