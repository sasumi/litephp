<?php
/**
 * Created by PhpStorm.
 * User: sasumi
 * Date: 2015/9/29
 * Time: 22:54
 */
use Lite\Core\Router;

return array(
	'mode' => Router::MODE_NORMAL
);