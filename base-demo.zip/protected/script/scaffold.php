<?php
use Lite\Cli\CodeGenerator;

include '../../../litephp/bootstrap.php';
CodeGenerator::Load();