//批量操作交互
seajs.use(['jquery', 'ywj/msg', 'ywj/net', 'ywj/popup', 'ywj/msg'], function($, msg, net, Pop, Msg){
	var $body = $('body');

	var CGI_ADD_SAMPLE = window['CGI_ADD_SAMPLE'];
	var MSG_LOAD_TIME = 10000;
	var DEF_POPUP_WIDTH = 600;

	var MSG_SHOW_TIME = (function(){
		return $.extend({
			err: 1,
			succ: 1,
			tip: 1
		}, window['MSG_SHOW_TIME'] || {});
	})();

	var showMsg = function(message, type, time){
		type = type || 'err';
		Msg.show(message, type, time || MSG_SHOW_TIME[type]);
	};

	/**
	 * tag组件
	 * @param $tags_input
	 */
	(function(){
		var update_tags_input = function($tags_input){
			var value = [];
			$tags_input.find('li>span[class!="del-tag"]').each(function(){
				value.push($(this).text());
			});
			var $val = $tags_input.find('input[type=hidden]');
			$val.val(value.join(','));
		};

		$body.delegate('.tags-input .del-tag', 'click', function(){
			var $ti = $(this).closest('.tags-input');
			$(this).parent().remove();
			update_tags_input($ti);
		});

		$body.delegate('.tags-input input[type=text]', 'keydown', function(e){
			var val = $.trim(this.value);
			if(val && e.keyCode == 13){
				var vs = val.split(',');
				for(var i=0; i<vs.length; i++){
					$('<li><span class="del-tag" title="删除">x</span><span>'+vs[i]+'</span></li>').appendTo($(this).closest('.tags-input').find('ul'));
				}
				this.value = '';
				update_tags_input($(this).closest('.tags-input'));
			}

			if(e.keyCode == 13){
				return false;
			}
		});
	})();

	/**
	 * 弹窗刷新组件
	 */
	$body.delegate('[rel=popup-refresh]', 'click', function(){
		var $node = $(this);
		var POPUP_ON_LOADING = 'data-popup-on-loading-flag';
		var RET = this.tagName == 'A' ? false : null;

		if($node.attr(POPUP_ON_LOADING) == 1){
			showMsg('正在加载页面...', 'load', MSG_LOAD_TIME);
			$('.ywj-msg-container-wrap').css('background', 'rgba(0,0,0,0.2)'); //style hack
			return RET;
		}

		$node.attr(POPUP_ON_LOADING, 1);
		var src = net.mergeCgiUri($node.attr('href'), {'ref':'iframe'});
		var width = parseFloat($node.data('width')) || DEF_POPUP_WIDTH;
		var height = parseFloat($node.data('height')) || 0;
		var title = $node.attr('title') || $node.html() || '';
		var conf = {
			title: title,
			content: {src:src},
			width: width,
			moveEnable: true,
			topCloseBtn: true,
			buttons: []
		};
		if(height){
			conf.height = height;
		}
		var p = new Pop(conf);
		p.onClose = function(){
			location.reload();
		};
		p.show();
		return RET;
	});
});